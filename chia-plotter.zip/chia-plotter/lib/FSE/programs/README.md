New Generation Entropy library
==============================

Note on licenses
----------------

The New Generation Entropy library is BSD Licensed.

The test tools, present into this directory, are GPLv2 licensed.

zlib's huffman implementation is thanks to Frederic Kayser (Caveman)

